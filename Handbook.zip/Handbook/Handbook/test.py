

# import flask_pymysql
# from sqlalchemy import create_engine, Column, Integer, String, func


#-*-coding:utf-8-*-
from flask import Flask

from App.basicConfigurations.views import basic
from App.checkHandbook.views import check
from App.departmentConfigurations.views import department
from App.login import login
from App.readHandbook.views import read
from App.handbookInput.views import input
from App.rightConfigurations.views import right
from App.main.views import main
from App.models import db




app = Flask(__name__)






#连接mysql数据库
SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://{username}:{password}@{hostname}/{databasename}".format(
    # username="scan",
    # password='wzhs123456',
    username="root",
    password="wzhs6666",
    hostname="127.0.0.1",
    databasename="flask$comments",
)
#对数据库进行配置
app.config["SQLALCHEMY_DATABASE_URI"] = SQLALCHEMY_DATABASE_URI
app.config["SQLALCHEMY_POOL_RECYCLE"] = 299
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
db.init_app(app)






#将数据库实例化


comments = []



#手册（手册名称，手册文件，创建时间，更新时间）
class handbook_base(db.Model):
    __tablename__ = "handbook"

    handbook_name = db.Column(db.String(767), primary_key=True)
    handbook_file = db.Column(db.String(767), nullable=True)
    update_time = db.Column(db.DateTime, nullable=True)
    creation_time = db.Column(db.DateTime, nullable=True)
    # --在procedure中使用了反向引用
    # handbook.procedures可以获取该手册的所有程序对象


#部门（部门名称）
class department_base(db.Model):
    __tablename__ = "department"

    department_name = db.Column(db.String(767), primary_key=True)
    update_time = db.Column(db.DateTime, nullable=True)
    creation_time = db.Column(db.DateTime, nullable=True)
    # --在position中使用了反向引用
    # department.positions可以获取该部门的所有岗位对象
    # --在user中使用了反向引用
    # department.users可以获取该部门的所有人员对象
    # --在work_name中使用了反向引用
    # department.work_names可以获取该部门的所有工作名称对象
    # --在user_work_abutment中使用了反向引用
    # department.user_work_abutments可以获取该部门的所有人员工作对接对象
    # --在flow_path中使用了反向引用
    # department.flow_paths可以获取该部门的所有流程工作对接对象
    # --在user_right中使用了反向引用
    # department.user_rights可以获取该部门的所有权限对象

#岗位（岗位名称，所属部门）
class position_base(db.Model):
    __tablename__ = "position"

    position_name = db.Column(db.String(767), primary_key=True)
    own_department_name = db.Column(db.String(767), db.ForeignKey('department.department_name'))
    department = db.relationship('department_base', backref=db.backref('positions'))#正反向引用
    #department.positions可以获取该部门的所有岗位对象
    #position.department可以获取该岗位所在的部门对象

    # --在user中使用了反向引用
    # position.users可以获取该岗位的所有人员对象


#人员（人员姓名，密码，性别，电子邮件，电话，所属部门，岗位名称，创建时间，更新时间）
class user_base(db.Model):
    __tablename__ = "user"

    user_name = db.Column(db.String(767), primary_key=True)
    pass_word = db.Column(db.String(767),nullable=False)
    sex = db.Column(db.String(5), nullable=False)
    e_mail = db.Column(db.String(767), nullable=True)
    phone = db.Column(db.String(767),nullable=True)
    belong_department_name = db.Column(db.String(767), db.ForeignKey('department.department_name'))
    department = db.relationship('department_base', backref=db.backref('users'))  # 正反向引用
    # department.users可以获取该部门的所有人员对象
    # user.department可以获取该人员所在的部门对象
    work_position_name = db.Column(db.String(767), db.ForeignKey('position.position_name'))
    position = db.relationship('position_base', backref=db.backref('users'))  # 正反向引用
    # position.users可以获取该岗位的所有人员对象
    # user.position可以获取该人员所在的岗位对象
    update_time = db.Column(db.DateTime, nullable=True)
    creation_time = db.Column(db.DateTime, nullable=True)


#工作程序（程序编号procedureNumber-string，程序名称procedureName-string，手册文件，目的purpose-string，适用范围applicationRange-string，
# 名词术语terms-string，依据according-string，程序procedure-string，存档document-file，表格和附件attachment-file，流程图diagram-file，
# 程序文件procedureFile-file，修订版本revision-string，
# 创建时间creationTime-datetime，更新时间updateTime-datetime）

class procedure_base(db.Model):
    __tablename__ = "procedure"

    procedure_name = db.Column(db.String(767), primary_key=True)
    procedure_number = db.Column(db.String(767), nullable=True)
    purpose = db.Column(db.String(767), nullable=True)
    applicationRange = db.Column(db.String(767), nullable=True)
    terms = db.Column(db.String(767), nullable=True)
    according = db.Column(db.String(767), nullable=True)
    procedure = db.Column(db.String(767), nullable=True)
    document_file = db.Column(db.String(767), nullable=True)
    attachment_file = db.Column(db.String(767), nullable=True)
    diagram_file = db.Column(db.String(767), nullable=True)
    procedure_file = db.Column(db.String(767), nullable=True)
    revision = db.Column(db.String(767), nullable=True)
    update_time = db.Column(db.DateTime, nullable=True)
    creation_time = db.Column(db.DateTime, nullable=True)

    use_handbook_name = db.Column(db.String(767), db.ForeignKey('handbook.handbook_name'))
    handbook = db.relationship('handbook_base', backref=db.backref('procedures'))  # 正反向引用
    # handbook.procedures可以获取该手册的所有程序对象
    # procedure.handbook可以获取该程序所在的手册对象
    # --在flow_path中使用了反向引用
    # procedure.flow_paths可以获取该程序的所有流程工作对接对象





#工作名称（所属部门，工作名称（key），工作描述，创建时间，更新时间）
class work_name_base(db.Model):
    __tablename__ = "workName"

    work_name = db.Column(db.String(767), primary_key=True)
    work_description = db.Column(db.String(767), nullable=True)
    update_time = db.Column(db.DateTime, nullable=True)
    creation_time = db.Column(db.DateTime, nullable=True)
    belong_department_name = db.Column(db.String(767), db.ForeignKey('department.department_name'))
    department = db.relationship('department_base', backref=db.backref('work_names'))  # 正反向引用
    # department.work_names可以获取该部门的所有工作名称对象
    # workName.department可以获取该人员所在的部门对象
    # --在user_work_abutment中使用了反向引用
    # work_name.user_work_abutments可以获取该部门的所有人员工作对接对象


#人员工作对接（所属部门，工作名称，员工姓名（key)）
class user_work_abutment_base(db.Model):
    __tablename__ = "userWorkAbutment"

    user_name = db.Column(db.String(767), primary_key=True)
    work_name = db.Column(db.String(767), db.ForeignKey('workName.work_name'))
    work = db.relationship('work_name_base', backref=db.backref('user_work_abutments'))  # 正反向引用
    # work_name.user_work_abutments可以获取该工作名称的所有人员工作对接对象
    # user_work_abutment.work_name可以获取该人员工作对接所在的工作名称对象
    belong_department_name = db.Column(db.String(767), db.ForeignKey('department.department_name'))
    department = db.relationship('department_base', backref=db.backref('user_work_abutments'))  # 正反向引用
    # department.user_work_abutments可以获取该部门的所有人员工作对接对象
    # user_work_abutment.department可以获取该人员所在的部门对象



#流程工作对接（所属部门，程序名称，修订标识，流程名称（key），工作名称，工作规范，创建时间，更新时间)
class flow_path_base(db.Model):
    __tablename__ = "flowPath"

    flow_name = db.Column(db.String(767), primary_key=True)
    work_standard = db.Column(db.String(767), nullable=True)
    update_time = db.Column(db.DateTime, nullable=True)
    creation_time = db.Column(db.DateTime, nullable=True)
    belong_department_name = db.Column(db.String(767), db.ForeignKey('department.department_name'))
    department = db.relationship('department_base', backref=db.backref('flow_paths'))  # 正反向引用
    # department.flow_paths可以获取该部门的所有流程工作对接对象
    # flow_path.department可以获取该流程工作对接所在的部门对象
    work_name = db.Column(db.String(767), db.ForeignKey('workName.work_name'))
    work = db.relationship('work_name_base', backref=db.backref('flow_paths'))  # 正反向引用
    # work_name.flow_paths可以获取该工作名称的所有流程工作对接对象
    # flow_path.work_name可以获取该流程工作对接所在的工作名称对象
    procedure_name = db.Column(db.String(767), db.ForeignKey('procedure.procedure_name'))
    produce = db.relationship('procedure_base', backref=db.backref('flow_paths'))  # 正反向引用
    # procedure.flow_paths可以获取该程序的所有流程工作对接对象
    # flow_path.procedure可以获取该流程工作对接所在的工作名称对象
    revision_mark = db.Column(db.String(767), nullable=True)




#用户权限（所属部门，用户名（key），岗位名称，系统权限）
class user_right_base(db.Model):
    __tablename__ = "userRight"

    user_name = db.Column(db.String(767), primary_key=True)
    belong_department_name = db.Column(db.String(767), db.ForeignKey('department.department_name'))
    department = db.relationship('department_base', backref=db.backref('user_rights'))  # 正反向引用
    # department.user_rights可以获取该部门的所有权限对象
    # user_right.department可以获取该流程工作对接所在的部门对象
    work_position_name = db.Column(db.String(767), db.ForeignKey('position.position_name'))
    position = db.relationship('position_base', backref=db.backref('user_rights'))  # 正反向引用
    # position.user_rights可以获取该岗位的所有权限对象
    # user_right.position可以获取该权限对应的岗位对象

    #管理员权限
    right1 = db.Column(db.Boolean, nullable=False)
    #手册录入权限
    right2 = db.Column(db.Boolean, nullable=False)
    #基本配置权限
    right3 = db.Column(db.Boolean, nullable=False)
    #部门配置权限
    right4 = db.Column(db.Boolean, nullable=False)


if __name__ == '__main__':
    db.drop_all()
    db.create_all()