#-*-coding:utf-8-*-
# def init_extensions(app):
#     pass
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()