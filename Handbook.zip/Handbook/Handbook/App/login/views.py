#-*-coding:utf-8-*-
from flask import Blueprint

login = Blueprint('login',__name__)


#登录界面
@login.route('/',methods=['GET','POST'])
def check_user():
#判断是否存在该用户
#若不存在
    return 'username is not exit'
#若存在，判断是否是管理员
#管理员且密码正确 return jsonify({'username':'name','admin':1})
#普通用户且密码正确 return jsonify({'username':'name','admin':0})
#密码不正确 return 'password is wrong'