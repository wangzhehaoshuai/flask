#-*-coding:utf-8-*-
from flask import Blueprint
from flask import request
import json
from App.login import login
from App.__init__ import user_right_base, method, user_base




#登录界面
@login.route('/', methods=['GET', 'POST'])
def check_user():
    print('网哲好帅')
    data = method.get_request(request)
#检测前台参数是否合法
    if ('username' in data)  and  ('password' in data):
        username = data['username']
        password = data['password']
    else:
        #前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    user_query = user_base.query.filter_by(user_name=username,pass_word=password)
    count = user_query.count()
# 判断是否存在该用户
    if count > 0:
        right = user_right_base.query.get(username)
        if right == None:
            #后台数据库无对应权限信息
            content = json.dumps({"error_code": "1002"})
            resp = method.Response_headers(content)
            return resp
        else:
            json_str = {'login': 'true', 'right1': method.is_true(right.right1), 'right2': method.is_true(right.right2),
                        'right3': method.is_true(right.right3),
                        'right4': method.is_true(right.right4)}
            content = json.dumps(json_str)
            resp = method.Response_headers(content)
            print(resp)
            return resp

    else:
        json_str = {'login': 'false'}
        content = json.dumps(json_str)
        resp = method.Response_headers(content)
        print(resp)
        return resp
#若不存在 return 'username is not exit'
#若存在，判断是否是管理员
#管理员且密码正确 return jsonify({'username':'name','admin':1})
#普通用户且密码正确 return jsonify({'username':'name','admin':0})
#密码不正确 return 'password is wrong'