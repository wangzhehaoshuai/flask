#-*-coding:utf-8-*-
from flask import Blueprint

read = Blueprint('read',__name__)

from App.readHandbook import views