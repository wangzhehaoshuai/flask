#-*-coding:utf-8-*-
from flask import Blueprint

read = Blueprint('read',__name__)

#手册浏览
@read.route('/readHandbook',methods=['GET','POST'])
def show_handbook():
#显示手册列表
    return

def read_handbook():
#根据文件名传输文件
    return
