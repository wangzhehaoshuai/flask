#-*-coding:utf-8-*-
from flask import request
from flask import jsonify, send_from_directory
from App.readHandbook import read
import os
import json
from App.Method import method

#手册浏览
@read.route('/readHandbook')
def show_handbook():
#显示手册列表
    print("网哲好帅")
    hand_book_list = []
    method.listdir("C:\\Users\\Administrator\\Desktop\\手册整理", hand_book_list)
    print(hand_book_list)
    return jsonify(manualList=hand_book_list)



@read.route('/readHandbook/download',methods=['GET','POST'])
def read_handbook():
#根据文件名传输文件
    data = method.get_request(request)
#检测前台参数是否合法
    if 'manualName' in data:
        manual_name = data['manualName']
    else:
        #前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (manual_name == None) or (manual_name == ""):
        #文件名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    if '--' not in manual_name:
        #文件名不包含--
        content = json.dumps({"error_code": "1005"})
        resp = method.Response_headers(content)
        return resp


    direct = "C:\\Users\\Administrator\\Desktop\\手册整理"
    names = manual_name.split("--")
    dire_name1 = names[0]
    dire_name2 = names[1]
    file_name = names[-1]
    try:
        if dire_name2 == file_name:
            file_path = os.path.join(direct, dire_name1)
            response = send_from_directory(file_path, file_name, as_attachment=True)
            response.headers["Content-Disposition"] = "attachment;filename={}".format(file_name.encode().decode('latin-1'))
            return response
        else:
            file_path = os.path.join(direct, dire_name1)
            file_path = os.path.join(file_path, dire_name2)
            response = send_from_directory(file_path, file_name, as_attachment=True)
            response.headers["Content-Disposition"] = "attachment;filename={}".format(file_name.encode().decode('latin-1'))
            return response
    except:
        # 文件不存在
        content = json.dumps({"error_code": "1003"})
        resp = method.Response_headers(content)
        return resp
# if os.path.isdir(file_path):
#     response = send_from_directory(file_path, file_name, as_attachment=True)
#     response.headers["Content-Disposition"] = "attachment;filename={}".format(file_name.encode().decode('latin-1'))
#     return response
# else:
#     for file in os.listdir(direct):
#         file_path = os.path.join(direct, file)
#         file_path = os.path.join(file_path, dire_name)
#         if os.path.isdir(file_path):
#             response = send_from_directory(file_path, file_name, as_attachment=True)
#             response.headers["Content-Disposition"] = "attachment;filename={}".format(
#                 file_name.encode().decode('latin-1'))
#             return response
