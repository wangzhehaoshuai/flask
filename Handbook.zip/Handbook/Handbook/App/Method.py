from flask import Response
import os
import json
import datetime
from werkzeug.utils import secure_filename
class Method(object):
    def __init__(self):
        pass
    def file_name_split(self, manual_name):
        names = manual_name.split("--")
        dire_name1 = names[0]
        dire_name2 = names[1]
        file_name = names[-1]
        if dire_name2 == file_name:
            dire_name2 = 'null'
        return dire_name1, dire_name2, file_name
    def upload_path(self, manual_name):
        direct = "C:\\Users\\Administrator\\Desktop\\手册整理"
        names = manual_name.split("--")
        dire_name1 = names[0]
        dire_name2 = names[1]
        file_name = names[-1]
        if dire_name2 == file_name:
            file_path = os.path.join(direct, dire_name1, secure_filename(file_name))
            return file_path
        else:
            file_path = os.path.join(direct, dire_name1)
            file_path = os.path.join(file_path, dire_name2, secure_filename(file_name))
            return file_path



    def get_request(self, request):
        if request.method == 'POST':
            print(request)
            # print("form:"+request.form)
            data = request.form.to_dict()
        elif request.method == 'GET':
            print(request)
            data = request.args.to_dict()
        return data

    def Response_headers(self, content):
        resp = Response(content)
        resp.headers['Access-Control-Allow-Origin'] = '*'
        return resp
    def is_str_true(self, str):
        if str == 'true':
            judge = True
        else:
            judge = False
        return judge
    def is_true(self, judge):
        if judge:
            str = 'true'
        else:
            str = 'false'
        return str

    def listdir(self, path, list_name):
        for file in os.listdir(path):
            file_path = os.path.join(path, file)
            if os.path.isdir(file_path):
                self.listdir(file_path, list_name)
            else:
                path_spilt = file_path.split('\\')
                dir_name1 = path_spilt[-3]
                dir_name2 = path_spilt[-2]
                file_name = path_spilt[-1]
                if dir_name1 == '手册整理':
                    string = dir_name2 + "--" + file_name
                else:
                    string = dir_name1 + "--" + dir_name2 + "--" + file_name
                #print(string)
                list_name.append(string)

class DateEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj,datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj,datetime.date):
            return obj.strftime("%Y-%m-%d")
        else:
            return json.JSONEncoder.default(self, obj)

method = Method()