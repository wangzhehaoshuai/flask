#-*-coding:utf-8-*-
from flask import request
from flask import jsonify, send_from_directory
from App.rightConfigurations import right
import os
import json
from App.Method import method
from App.models import user_right_base, db, user_base

#用户权限配置

@right.route('/')
def show_right():
#显示用户列表
    user_names = user_right_base.query.all()
    users = []
    for name in user_names:
        information = name.user_name + '--' + name.belong_department_name + '--' + name.work_position_name + '--' + \
                      method.is_true(name.right1) + '--' + method.is_true(name.right2) + \
                      '--' + method.is_true(name.right3) + '--' + method.is_true(name.right4)
        users.append(information)
    print(users)
    return jsonify(userList=users)


@right.route('/find', methods=['GET', 'POST'])
def find_right():
#查询用户列表
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'keyWord' in data:
        key_word = data['keyWord']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (key_word == None) or (key_word == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    user_names = user_right_base.query.filter(user_right_base.user_name.contains(key_word)).all()
    users = []
    for name in user_names:
        information = name.user_name + '--' + name.belong_department_name + '--' + name.work_position_name + '--' +\
                      method.is_true(name.right1) + '--' + method.is_true(name.right2) +\
                      '--' + method.is_true(name.right3) + '--' + method.is_true(name.right4)
        users.append(information)
    print(users)
    return jsonify(userList=users)

#重置密码
@right.route('/reset', methods=['GET', 'POST'])
def reset_password():

    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'username' in data:
        user_name = data['username']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (user_name == None) or (user_name == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    try:
        user = user_base.query.get(user_name)
        user.pass_word = '123456'
        db.session.add(user)
        db.session.commit()
        return jsonify(username=user_name, isResetRight='true')
    except:
        db.session.rollback()
        return jsonify(isResetRight='false')

#修改
@right.route('/modify', methods=['GET', 'POST'])
def modify_right():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if ('username' in data) and ('right1' in data) and ('right2' in data) and ('right3' in data) and ('right4' in data):
        user_name = data['username']
        right1 = data['right1']
        right2 = data['right2']
        right3 = data['right3']
        right4 = data['right4']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (user_name == None) or (user_name == "") or (right1 == "") or (right2 == "") or (right3 == "") or (right4 == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    try:
        user = user_right_base.query.get(user_name)
        user.right1 = method.is_str_true(right1)
        user.right2 = method.is_str_true(right2)
        user.right3 = method.is_str_true(right3)
        user.right4 = method.is_str_true(right4)
        db.session.add(user)
        db.session.commit()
        return jsonify(username=user_name, right1=right1, right2=right2, right3=right3, right4=right4, isModifyRight='true')
    except:
        db.session.rollback()
        return jsonify(isModifyRight='false')
