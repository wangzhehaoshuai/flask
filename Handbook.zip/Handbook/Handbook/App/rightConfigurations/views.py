#-*-coding:utf-8-*-
from flask import Blueprint

right = Blueprint('rightConfiguration',__name__)

#用户权限配置

@right.route('/',methods=['GET','POST'])
def show_right():
#显示用户列表
    return
def find_right():
#查询用户列表
    return

#修改
@right.route('/modify',methods=['GET','POST'])
def modify_right():
    return

#重置密码
@right.route('/reset',methods=['GET','POST'])
def reset_password():
    return
