#-*-coding:utf-8-*-
from flask import Blueprint

right = Blueprint('rightConfiguration', __name__)

from App.rightConfigurations import views