#-*-coding:utf-8-*-
from flask import Blueprint

main = Blueprint('main',__name__)

@main.route('/')
def index():
    return 'The server is running.'



