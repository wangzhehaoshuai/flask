#-*-coding:utf-8-*-
from flask import Blueprint

department = Blueprint('departmentConfigurations',__name__)

from App.departmentConfigurations import views