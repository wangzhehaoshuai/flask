#-*-coding:utf-8-*-
from flask import Blueprint

department = Blueprint('departmentConfigurations',__name__)
#部门配置

#工作名称配置
@department.route('/name',methods=['GET'])
def show_name():
#显示工作名称列表
    return

#新建工作名称
@department.route('/name/add',methods=['GET','POST'])
def add_name():
    return

#修改工作名称
@department.route('/name/modify',methods=['GET','POST'])
def modify_name():
    return

#查看工作名称
@department.route('/name/check',methods=['GET'])
def check_name():
    return

#删除工作名称
@department.route('/name/delete',methods=['GET','POST'])
def delete_name():
    return



#人员工作对接
@department.route('/name_position',methods=['GET','POST'])
def show_name_position():
#显示人员工作对接列表
    return
def find_name_position():
#查询人员工作对接
    return

#新建人员工作对接
@department.route('/name_position/add',methods=['GET','POST'])
def add_name_position():
    return

#删除人员工作对接
@department.route('/name_position/delete',methods=['GET','POST'])
def del_name_position():
    return



#流程工作对接
@department.route('/procedure_position',methods=['GET','POST'])
def show_procedure_position():
#显示流程工作对接列表
    return
def find_procedure_position():
#查询流程工作对接
    return

#新建流程工作对接
@department.route('/procedure_position/add',methods=['GET','POST'])
def add_procedure_position():
    return

#修改流程工作对接
@department.route('/procedure_position/modify',methods=['GET','POST'])
def modify_procedure_position():
    return

#查看流程工作对接
@department.route('/procedure_position/check',methods=['GET'])
def check_procedure_position():
    return

#删除流程工作对接
@department.route('/procedure_position/delete',methods=['GET','POST'])
def del_procedure_position():
    return '王哲天下第一帅'
