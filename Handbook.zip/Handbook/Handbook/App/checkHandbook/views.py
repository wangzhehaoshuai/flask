#-*-coding:utf-8-*-
from flask import Blueprint

check = Blueprint('checkHandbook',__name__)

#手册查询

@check.route('/',methods=['GET','POST'])
def show_procedure():
#显示工作程序
    return '王哲好帅'

def find_procedure():
#查询程序
    return