#-*-coding:utf-8-*-
from flask import Flask

from App.basicConfigurations.views import basic
from App.checkHandbook.views import check
from App.departmentConfigurations.views import department
from App.login import login
from App.readHandbook.views import read
from App.handbookInput.views import input
from App.rightConfigurations.views import right
from App.main.views import main
from App.models import db




app = Flask(__name__)


#注册蓝
app.register_blueprint(main, url_prefix='/')
app.register_blueprint(login, url_prefix='/login')
app.register_blueprint(read, url_prefix='/read')
app.register_blueprint(basic, url_prefix='/basicConfigurations')
app.register_blueprint(input, url_prefix='/handbookInput')
app.register_blueprint(department, url_prefix='/departmentConfigurations')
app.register_blueprint(right,url_prefix='/right')
app.register_blueprint(check, url_prefix='/checkHandbook')



#连接mysql数据库
SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://{username}:{password}@{hostname}/{databasename}".format(
    # username="scan",
    # password='wzhs123456',
    username="root",
    password="wzhs6666",
    hostname="127.0.0.1",
    databasename="flask$comments",
)
#对数据库进行配置
app.config["SQLALCHEMY_DATABASE_URI"] = SQLALCHEMY_DATABASE_URI
app.config["SQLALCHEMY_POOL_RECYCLE"] = 299
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

with app.app_context():
    db.init_app(app)
    #db.drop_all()
    db.create_all()



