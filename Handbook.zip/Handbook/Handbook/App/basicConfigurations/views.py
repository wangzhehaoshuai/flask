#-*-coding:utf-8-*-
from App.basicConfigurations import basic
from App.models import department_base, db, position_base, user_base, user_right_base
from flask import jsonify
from App.Method import method,DateEncoder
from flask import request
import json
import datetime
#基本配置



#部门配置
@basic.route('/department')
def show_department():
#显示部门列表
    department_names = db.session.query(department_base.department_name).all()
    departments = []
    for name in department_names:
        departments.append(name[0])
    print(departments)
    return jsonify(departmentList=departments)

#新增部门
@basic.route('/department/add', methods=['GET','POST'])
def add_department():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if ('addDepartment' in data):
        add_department = data['addDepartment']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (add_department == None) or (add_department == ""):
        #参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    department_query = department_base.query.filter_by(department_name=add_department)
    count = department_query.count()
    if count > 0:
        db.session.close()
        json_str = {'isAddDepartment': 'false'}
        content = json.dumps(json_str)
        resp = method.Response_headers(content)
        return resp
    else:
        department_element = department_base(department_name=add_department, creation_time=datetime.datetime.now(),
                                             update_time=datetime.datetime.now())
        db.session.add(department_element)
        db.session.commit()
        json_str = {'isAddDepartment': 'true'}
        content = json.dumps(json_str)
        resp = method.Response_headers(content)
        return resp


#删除部门
@basic.route('/department/delete',methods=['GET', 'POST'])
def del_department():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if ('deleteDepartment' in data):
        delete_department = data['deleteDepartment']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (delete_department == None) or (delete_department == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    department_element = department_base.query.get(delete_department)
    if department_element is not None:
        print(department_element)
        creation_time = department_element.creation_time
        update_time = department_element.update_time
        #department_element = department_base(department_name=delete_department)
        db.session.delete(department_element)
        db.session.commit()
        json_str = {'department': delete_department, 'isDeleteDepartment': 'true', 'createTime': creation_time,
                    'updateTime': update_time}
        content = json.dumps(json_str, cls=DateEncoder)
        print(content)
        resp = method.Response_headers(content)
        return resp
    else:
        db.session.close()
        json_str = {'isDeleteDepartment': 'false'}
        content = json.dumps(json_str)
        resp = method.Response_headers(content)
        return resp





#岗位配置
@basic.route('/position')
def show_position():
#显示岗位列表
    position_names = position_base.query.all()
    positions = []
    for name in position_names:
        positions.append(name.position_name+'--'+name.own_department_name)
    print(positions)
    return jsonify(positionList=positions)

#新增岗位
@basic.route('/position/add',methods=['GET', 'POST'])
def add_position():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if ('itsDepartment' in data) and ('addPosition' in data):
        its_department = data['itsDepartment']
        add_position = data['addPosition']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (add_position == None) or (add_position == ""):
        #参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    department_query = department_base.query.filter_by(department_name=its_department)
    count_department = department_query.count()
    if count_department == 0:#如果部门不存在，则职位添加失败
        db.session.close()
        json_str = {'isAddPosition': 'false'}
        content = json.dumps(json_str)
        resp = method.Response_headers(content)
        return resp
    else:
        position_query = position_base.query.filter_by(position_name=add_position, own_department_name=its_department)
        count_position = position_query.count()
        if count_position > 0:#如果在该部门职位已存在，则职位添加失败
            db.session.close()
            json_str = {'isAddPosition': 'false'}
            content = json.dumps(json_str)
            resp = method.Response_headers(content)
            return resp
        else:
            position_element = position_base(position_name=add_position, own_department_name=its_department)
            db.session.add(position_element)
            db.session.commit()
            json_str = {'isAddPosition': 'true'}
            content = json.dumps(json_str)
            resp = method.Response_headers(content)
            return resp

#删除岗位
@basic.route('/position/delete', methods=['GET', 'POST'])
def del_position():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if ('itsDepartment' in data) and ('deletePosition' in data):
        its_department = data['itsDepartment']
        delete_position = data['deletePosition']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (delete_position == None) or (delete_position == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    position_element = position_base.query.get(delete_position)
    if position_element is not None:
        print(position_element)
        creation_time = position_element.department.creation_time
        update_time = position_element.department.update_time
        #department_element = department_base(department_name=delete_department)
        db.session.delete(position_element)
        db.session.commit()
        json_str = {'position': delete_position, 'department': its_department, 'isDeletePosition': 'true', 'createTime': creation_time,
                    'updateTime': update_time}
        content = json.dumps(json_str, cls=DateEncoder)
        print(content)
        resp = method.Response_headers(content)
        return resp
    else:
        db.session.close()
        json_str = {'isDeletePosition': 'false'}
        content = json.dumps(json_str)
        resp = method.Response_headers(content)
        return resp


#人员配置
@basic.route('/human')
def show_human():
#显示人员配置列表
    user_names = user_base.query.all()
    users = []
    for name in user_names:
        users.append(name.user_name+'--'+method.is_empty(name.work_position_name)+
                     '--'+method.is_empty(name.belong_department_name))
    print(users)
    return jsonify(humanList=users)


#人员配置
@basic.route('/human/find', methods=['GET', 'POST'])
def find_human():
    #显示人员配置列表
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'keyWord' in data:
        key_word = data['keyWord']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (key_word == None) or (key_word == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    user_names = user_right_base.query.filter(user_base.user_name.contains(key_word)).all()
    users = []
    for name in user_names:
        users.append(name.user_name+'--'+method.is_empty(name.work_position_name)+
                     '--'+method.is_empty(name.belong_department_name))
    print(users)
    return jsonify(humanList=users)


#人员新建
@basic.route('/human/add', methods=['GET', 'POST'])
def add_human():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if ('name' in data) and ('sex' in data) and ('email' in data) and ('phone' in data) \
            and ('department' in data) and ('position' in data):
        name = data['name']
        sex = data['sex']
        email = data['email']
        phone = data['phone']
        department = data['department']
        position = data['position']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (name is None) or (name == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    user = user_base(user_name=name, pass_word='123456', sex=sex, e_mail=email, phone=phone,
                     belong_department_name=department,
                     work_position_name=position, creation_time=datetime.datetime.now(),
                     update_time=datetime.datetime.now())
    user_right = user_right_base(user_name=name, belong_department_name=department, work_position_name=position,
                                 right1=False, right2=False, right3=False, right4=False)
    try:
        db.session.add(user)
        db.session.add(user_right)
        db.session.commit()
        return jsonify(isAddHuman='true')
    except:
        db.session.rollback()
        return jsonify(isAddHuman='false')


#人员修改
@basic.route('/human/modify', methods=['GET', 'POST'])
def modify_human():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if ('name' in data) and ('sex' in data) and ('email' in data) and ('phone' in data) \
            and ('department' in data) and ('position' in data):
        name = data['name']
        sex = data['sex']
        email = data['email']
        phone = data['phone']
        department = data['department']
        position = data['position']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (name is None) or (name == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    user = user_base.query.get(name)
    if user == None:
        return jsonify(isModifyHuman='false')
    user.sex = sex
    user.phone = phone
    user.e_mail = email
    user.belong_department_name = department
    user.work_position_name = position
    user.update_time = datetime.datetime.now()
    try:
        db.session.add(user)
        db.session.commit()
        return jsonify(name=name, sex=sex, email=email, phone=phone, department=department,
                       positione=position, isModifyHuman='true')
    except:
        db.session.rollback()
        return jsonify(isModifyHuman='false')

#查看
@basic.route('/human/check', methods=['GET', 'POST'])
def check_human():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'name' in data:
        name = data['name']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (name == None) or (name == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    try:
        user = user_base.query.filter_by(user_name=name).first()
        return jsonify(name=user.user_name, sex=user.sex, email=user.e_mail, phone=user.phone,
                       department=user.belong_department_name, position=user.work_position_name,
                       createTime=user.creation_time, updateTime=user.update_time, exists='true')
    except:
        db.session.rollback()
        return jsonify(exists='false')

#删除
@basic.route('/human/del', methods=['GET', 'POST'])
def del_human():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'name' in data:
        name = data['name']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (name == None) or (name == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    try:
        user = user_base.query.filter_by(user_name=name).first()
        user_right = user_right_base.query.filter_by(user_name=name).first()
        sex = user.sex
        email = user.e_mail
        phone = user.phone
        department = user.belong_department_name
        position = user.work_position_name
        createTime = user.creation_time
        updateTime = user.update_time
        json_str = {'sex': sex, 'position': position, 'department': department,
                    'isDeleteHuman': 'true', 'createTime': createTime,
                    'updateTime': updateTime, 'email': email, 'phone': phone, 'name': name}
        content = json.dumps(json_str, cls=DateEncoder)
        print(content)
        db.session.delete(user)
        db.session.delete(user_right)
        db.session.commit()
        resp = method.Response_headers(content)
        return resp
    except:
        db.session.rollback()
        return jsonify(isDeleteHuman='false')
