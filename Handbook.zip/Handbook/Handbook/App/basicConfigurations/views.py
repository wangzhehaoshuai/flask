#-*-coding:utf-8-*-
from flask import Blueprint


basic = Blueprint('basicConfigurations',__name__)
#基本配置



#部门配置
@basic.route('/department',methods=['GET'])
def show_department():
#显示部门列表
    return '王哲就是帅'

#新增部门
@basic.route('/department/add',methods=['GET','POST'])
def add_department():
    return

#删除部门
@basic.route('/department/delete',methods=['GET','POST'])
def del_department():
    return



#岗位配置
@basic.route('/position',methods=['GET'])
def show_position():
#显示岗位列表
    return

#新增岗位
@basic.route('/position/add',methods=['GET','POST'])
def add_position():
    return

#删除岗位
@basic.route('/position/delete',methods=['GET','POST'])
def del_position():
    return


#人员配置
@basic.route('/human',methods=['GET','POST'])
def show_human():
#显示人员配置列表
    return
def find_human():
#查询
    return

#人员新建
@basic.route('/huamn/add',methods=['GET','POST'])
def add_human():
    return

#人员修改
@basic.route('/huamn/modify',methods=['GET','POST'])
def modify_human():
    return

#查看
@basic.route('/huamn/check',methods=['GET'])
def check_human():
    return

#删除
@basic.route('/huamn/del',methods=['GET','POST'])
def del_human():
    return
