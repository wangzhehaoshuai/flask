#-*-coding:utf-8-*-
from flask import Blueprint

basic = Blueprint('basicConfigurations', __name__)

from App.basicConfigurations import views