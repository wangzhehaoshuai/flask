#-*-coding:utf-8-*-
from flask import Blueprint

input = Blueprint('handbookInput', __name__)

from App.handbookInput import views