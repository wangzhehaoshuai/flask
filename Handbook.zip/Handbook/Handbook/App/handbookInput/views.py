#-*-coding:utf-8-*-
from flask import request
from flask import jsonify, render_template
from App.handbookInput import input
import os
import json
from App.Method import method, DateEncoder, date_encoder
import datetime
from App.models import handbook_base, db, user_base, procedure_base
import shutil

#手册录入

#手册录入管理
@input.route('/handbook')
def show_handbook():
#显示手册列表
    # direct = "C:\\Users\\Administrator\\Desktop\\手册整理"
    # files = []
    # for file in os.listdir(direct):
    #     file_path = os.path.join(direct, file)
    #     if os.path.isdir(file_path):
    #         files.append(file)
    # print(files)
    # return jsonify(manualName=files)
    handbooks = handbook_base.query.all()
    list = []
    for name in handbooks:
        list.append(name.handbook_name+'--'+date_encoder.default(name.update_time)+
                    '--'+date_encoder.default(name.creation_time))
    print(list)
    return jsonify(positionList=list)

#新建手册
@input.route('/handbook/add', methods=['GET', 'POST'])
def add_handbook():
    if request.method == 'POST':
        file = request.files['manualFile']
        data = request.form.to_dict()
        # 检测前台参数是否合法
        if 'manualName' in data:
            manual_name = data['manualName']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (manual_name == None) or (manual_name == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        if '--' not in manual_name:
            # 文件名不包含--
            file_path = method.handbook_path(manual_name)
            os.mkdir(file_path)
        else:
            file_path = method.handbook_path(manual_name)
            file_extension = os.path.splitext(file.filename)[1]
            file_path = file_path + file_extension
            print(file_path)
            if os.path.exists(file_path):
                # 文件已存在
                content = json.dumps({"error_code": "1007"})
                resp = method.Response_headers(content)
                return resp
            try:
                file.save(file_path)
            except:
                # 该目录不存在
                content = json.dumps({"error_code": "1009"})
                resp = method.Response_headers(content)
                return resp
        handbook = handbook_base.query.get(manual_name)
        if handbook is None:
            return jsonify(isAddManual='false')
        handbook.handbook_file = file_path
        handbook.update_time = datetime.datetime.now()
        try:
            db.session.add(handbook)
            db.session.commit()
            return jsonify(isAddManual='true')
        except:
            db.session.rollback()
            if os.path.isfile(file_path):
                os.remove(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path, True)
            return jsonify(isAddManual='false')
    elif request.method == 'GET':
        data = method.get_request(request)
        # 检测前台参数是否合法
        if 'manualName' in data:
            manual_name = data['manualName']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (manual_name == None) or (manual_name == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        # if '--' not in manual_name:
        #     # 文件名不包含--
        #     content = json.dumps({"error_code": "1005"})
        #     resp = method.Response_headers(content)
        #     return resp
        # file_path = method.upload_path(manual_name)
        #file_name, file_path = method.handbook_path(manual_name)
        # dir_name1, dir_name2, file_name = method.file_name_split(manual_name)
        handbook = handbook_base(handbook_name=manual_name,
                                 handbook_file="该文件尚未上传", creation_time=datetime.datetime.now(),
                                 update_time=datetime.datetime.now())
        try:
            db.session.add(handbook)
            db.session.commit()
            return jsonify(isAddManual='true')
        except:
            db.session.rollback()
            return jsonify(isAddManual='false')

# 新建手册的测试html
@input.route('/handbook/add1', methods=['GET', 'POST'])
def add_handbook_test():
    if request.method == 'POST':
        file = request.files['manualFile']
        data = request.form.to_dict()
        # 检测前台参数是否合法
        if 'manualName' in data:
            manual_name = data['manualName']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (manual_name == None) or (manual_name == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        if '--' not in manual_name:
            # 文件名不包含--
            file_path = method.handbook_path(manual_name)
            os.mkdir(file_path)
        else:
            file_path = method.handbook_path(manual_name)
            file_extension = os.path.splitext(file.filename)[1]
            file_path = file_path + file_extension
            print(file_path)
            if os.path.exists(file_path):
                # 文件已存在
                content = json.dumps({"error_code": "1007"})
                resp = method.Response_headers(content)
                return resp
            try:
                file.save(file_path)
            except:
                # 该目录不存在
                content = json.dumps({"error_code": "1009"})
                resp = method.Response_headers(content)
                return resp
        handbook = handbook_base.query.get(manual_name)
        if handbook is None:
            return jsonify(isAddManual='false')
        handbook.handbook_file = file_path
        handbook.update_time = datetime.datetime.now()
        try:
            db.session.add(handbook)
            db.session.commit()
            return jsonify(isAddManual='true')
        except:
            db.session.rollback()
            if os.path.isfile(file_path):
                os.remove(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path, True)
            return jsonify(isAddManual='false')
    return render_template('upload.html')

#修改手册
@input.route('/handbook/modify', methods=['GET', 'POST'])
def modify_handbook():
    if request.method == 'POST':
        file = request.files['manualFile']
        data = request.form.to_dict()
        # 检测前台参数是否合法
        if 'manualName' in data:
            manual_name = data['manualName']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (manual_name is None) or (manual_name == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        if '--' not in manual_name:
            # 文件名不包含--
            content = json.dumps({"error_code": "1005"})
            resp = method.Response_headers(content)
            return resp
        file_path = method.handbook_path(manual_name)
        file_extension = os.path.splitext(file.filename)[1]
        file_path = file_path + file_extension
        if not os.path.exists(file_path):
            # 文件不存在
            content = json.dumps({"error_code": "1008"})
            resp = method.Response_headers(content)
            return resp
        try:
            file.save(file_path)
            return jsonify(isModifyManual='true')
        except:
            return jsonify(isModifyManual='false')
    return render_template('upload.html')

#手册查看
@input.route('/handbook/check', methods=['GET', 'POST'])
def check_handbook():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'manualName' in data:
        manual_name = data['manualName']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (manual_name == None) or (manual_name == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    try:
        handbook = handbook_base.query.get(manual_name)
        json_str = {'manualName': handbook.handbook_name, 'createTime': handbook.creation_time,
                    'updateTime': handbook.update_time,
                    'exists': 'true'}
        content = json.dumps(json_str, cls=DateEncoder)
        print(content)
        resp = method.Response_headers(content)
        return resp
    except:
        db.session.rollback()
        return jsonify(exists='false')

#手册删除
@input.route('/handbook/delete', methods=['GET', 'POST'])
def del_handbook():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'manualName' in data:
        name = data['manualName']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (name == None) or (name == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    # dir_name1, dir_name2, file_name = method.file_name_split(name)
    #file_path = method.handbook_path(name)
    try:
        handbook = handbook_base.query.filter_by(handbook_name=name).first()
        createTime = handbook.creation_time
        updateTime = handbook.update_time
        json_str = {'manualName': name, 'createTime': createTime, 'updateTime': updateTime, 'isDeleteManual': 'true'}
        content = json.dumps(json_str, cls=DateEncoder)
        print(content)
        db.session.delete(handbook)
        db.session.commit()
        resp = method.Response_headers(content)
        return resp
    except:
        db.session.rollback()
        return jsonify(isDeleteManual='false')


#程序录入
@input.route('/procedure', methods=['GET', 'POST'])
def show_procedure():
#显示工作程序列表
    procedures = procedure_base.query.all()
    list = []
    for name in procedures:
        list.append(name.procedure_number + '--' + name.procedure_name +
                    '--' + name.chapter + '--' + method.is_empty(name.use_handbook_name)
                    + '--' + method.is_empty(name.purpose) + '--' + method.is_empty(name.applicationRange) + '--' +
                     method.is_empty(name.terms) + '--' + method.is_empty(name.according) + '--' +
                     method.is_empty(name.procedure) + '--' + method.is_empty(name.attachment_file) + '--' +
                     method.is_empty(name.diagram_file) + '--' + method.is_empty(name.procedure_file) + '--' +
                    method.is_empty(name.revision) + '--' + date_encoder.default(name.update_time) +
                    '--' + date_encoder.default(name.creation_time))
    print(list)
    return jsonify(positionList=list)


@input.route('/procedure/find', methods=['GET', 'POST'])
def find_procedure():
#查询程序
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'keyWord' in data:
        key_word = data['keyWord']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (key_word is None) or (key_word == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp

    procedures = []
    procedures_query = procedure_base.query.filter(procedure_base.procedure_number.contains(key_word)).all()
    procedures.append(procedures_query)
    procedures_query = procedure_base.query.filter(procedure_base.procedure_name.contains(key_word)).all()
    procedures.append(procedures_query)
    procedures_query = procedure_base.query.filter(procedure_base.chapter.contains(key_word)).all()
    procedures.append(procedures_query)
    procedures_query = procedure_base.query.filter(procedure_base.use_handbook_name.contains(key_word)).all()
    procedures.append(procedures_query)
    procedures_query = procedure_base.query.filter(procedure_base.purpose.contains(key_word)).all()
    procedures.append(procedures_query)
    procedures_query = procedure_base.query.filter(procedure_base.applicationRange.contains(key_word)).all()
    procedures.append(procedures_query)
    procedures_query = procedure_base.query.filter(procedure_base.terms.contains(key_word)).all()
    procedures.append(procedures_query)
    procedures_query = procedure_base.query.filter(procedure_base.according.contains(key_word)).all()
    procedures.append(procedures_query)
    procedures_query = procedure_base.query.filter(procedure_base.procedure.contains(key_word)).all()
    procedures.append(procedures_query)
    procedures_query = procedure_base.query.filter(procedure_base.revision.contains(key_word)).all()
    procedures.append(procedures_query)
    #procedures_by_number = procedure_base.query.filter(procedure_base.procedure_number.contains(key_word)).all()

    list = []
    for procedure in procedures:
        for name in procedure:
            procedure_str = name.procedure_number + '--' + name.procedure_name +\
                            '--' + name.chapter + '--' + method.is_empty(name.use_handbook_name) +\
                            '--' + method.is_empty(name.purpose) + '--' + method.is_empty(name.applicationRange) +\
                            '--' + method.is_empty(name.terms) + '--' + method.is_empty(name.according) + '--' +\
                            method.is_empty(name.procedure) + '--' + method.is_empty(name.attachment_file) + '--' +\
                            method.is_empty(name.diagram_file) + '--' + method.is_empty(name.procedure_file) + '--' +\
                            method.is_empty(name.revision) + '--' + date_encoder.default(name.update_time) +\
                            '--' + date_encoder.default(name.creation_time)
            if procedure_str not in list:
                list.append(procedure_str)
    print(list)
    return jsonify(positionList=list)


#新建程序
@input.route('/procedure/add', methods=['GET', 'POST'])
def add_procedure():
    if request.method == 'POST':
        file = request.files['manualFile']
        data = request.form.to_dict()
        # 检测前台参数是否合法
        if 'procedureNumber' in data:
            procedure_number = data['procedureNumber']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (procedure_number is None) or (procedure_number == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        # if '--' not in manual_name:
        #     # 文件名不包含--
        #     content = json.dumps({"error_code": "1005"})
        #     resp = method.Response_headers(content)
        #     return resp
        # right, file_path = method.upload_path(manual_name)
        # if not right:
        #     content = json.dumps({"error_code": "1010"})
        #     resp = method.Response_headers(content)
        #     return resp
        procedure_new = procedure_base.query.get(procedure_number)
        file_path = method.upload_path(procedure_new.use_handbook_name+'--'+procedure_new.chapter+
                                       '--'+procedure_new.procedure_name)
        file_extension = os.path.splitext(file.filename)[1]
        file_path = file_path + file_extension
        print(file_path)
        if os.path.exists(file_path):
            # 文件已存在
            content = json.dumps({"error_code": "1007"})
            resp = method.Response_headers(content)
            return resp
        try:
            file.save(file_path)
        except:
            # 该目录不存在
            content = json.dumps({"error_code": "1009"})
            resp = method.Response_headers(content)
            return resp
        procedure = procedure_base.query.get(procedure_number)
        if procedure is None:
            return jsonify(isAddProcedure='false')
        procedure.procedure_file = file_path
        procedure.update_time = datetime.datetime.now()
        try:
            db.session.add(procedure)
            db.session.commit()
            return jsonify(isAddProcedure='true')
        except:
            db.session.rollback()
            if os.path.isfile(file_path):
                os.remove(file_path)
            return jsonify(isAddProcedure='false')
    elif request.method == 'GET':
        data = method.get_request(request)
        # 检测前台参数是否合法
        if ('manualName' in data) and ('procedureNumber' in data) and ('procedureName' in data) and ('chapter' in data):
            manual_name = data['manualName']
            procedure_number = data['procedureNumber']
            procedure_name = data['procedureName']
            chapter = data['chapter']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (manual_name is None) or (manual_name == "") or (procedure_number is None) or (procedure_number == "") or\
                (procedure_name is None) or (procedure_name == "") or (chapter is None) or (chapter == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        dir = method.procedure_dir_path(manual_name+'--'+chapter)
        print(dir)
        if not os.path.isdir(dir):
            # 该目录不存在
            content = json.dumps({"error_code": "1009"})
            resp = method.Response_headers(content)
            return resp
        if 'purpose' in data:
            purpose = data['purpose']
        else:
            purpose = ''
        if 'applicationRange' in data:
            application_range = data['applicationRange']
        else:
            application_range = ''
        if 'terms' in data:
            terms = data['terms']
        else:
            terms = ''
        if 'proof' in data:
            proof = data['proof']
        else:
            proof = ''
        if 'revision' in data:
            revision = data['revision']
        else:
            revision = ''
        procedure = procedure_base(procedure_number=procedure_number, procedure_name=procedure_name, chapter=chapter,
                                   purpose=purpose, applicationRange=application_range, terms=terms, according=proof,
                                   revision=revision, document_file="该文件尚未上传", attachment_file="该文件尚未上传",
                                   diagram_file="该文件尚未上传", procedure_file="该文件尚未上传",
                                   use_handbook_name=manual_name, creation_time=datetime.datetime.now(),
                                   update_time=datetime.datetime.now())
        try:
            db.session.add(procedure)
            db.session.commit()
            return jsonify(isAddProcedure='true')
        except:
            db.session.rollback()
            return jsonify(isAddProcedure='false')


# 新建手册的测试html
@input.route('/procedure/add1', methods=['GET', 'POST'])
def add_procedure_test():
    if request.method == 'POST':
        file = request.files['manualFile']
        data = request.form.to_dict()
        # 检测前台参数是否合法
        if 'procedureNumber' in data:
            procedure_number = data['procedureNumber']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (procedure_number is None) or (procedure_number == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        # if '--' not in manual_name:
        #     # 文件名不包含--
        #     content = json.dumps({"error_code": "1005"})
        #     resp = method.Response_headers(content)
        #     return resp
        # right, file_path = method.upload_path(manual_name)
        # if not right:
        #     content = json.dumps({"error_code": "1010"})
        #     resp = method.Response_headers(content)
        #     return resp
        procedure_new = procedure_base.query.get(procedure_number)
        file_path = method.upload_path(procedure_new.use_handbook_name+'--'+procedure_new.chapter+
                                       '--'+procedure_new.procedure_name)
        file_extension = os.path.splitext(file.filename)[1]
        file_path = file_path + file_extension
        print(file_path)
        if os.path.exists(file_path):
            # 文件已存在
            content = json.dumps({"error_code": "1007"})
            resp = method.Response_headers(content)
            return resp
        try:
            file.save(file_path)
        except:
            # 该目录不存在
            content = json.dumps({"error_code": "1009"})
            resp = method.Response_headers(content)
            return resp
        procedure = procedure_base.query.get(procedure_number)
        if procedure is None:
            return jsonify(isAddProcedure='false')
        procedure.procedure_file = file_path
        procedure.update_time = datetime.datetime.now()
        try:
            db.session.add(procedure)
            db.session.commit()
            return jsonify(isAddProcedure='true')
        except:
            db.session.rollback()
            if os.path.isfile(file_path):
                os.remove(file_path)
            return jsonify(isAddProcedure='false')
    return render_template('upload_procedure.html')


#修改程序
@input.route('/procedure/modify', methods=['GET', 'POST'])
def modify_procedure():
    if request.method == 'POST':
        file = request.files['manualFile']
        data = request.form.to_dict()
        # 检测前台参数是否合法
        if 'procedureNumber' in data:
            procedure_number = data['procedureNumber']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (procedure_number is None) or (procedure_number == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        procedure_new = procedure_base.query.get(procedure_number)
        file_path = method.upload_path(procedure_new.use_handbook_name+'--'+procedure_new.chapter+
                                       '--'+procedure_new.procedure_name)
        file_extension = os.path.splitext(file.filename)[1]
        file_path = file_path + file_extension
        print(file_path)
        if not os.path.exists(file_path):
            # 文件不存在
            content = json.dumps({"error_code": "1008"})
            resp = method.Response_headers(content)
            return resp
        try:
            file.save(file_path)
        except:
            # 该目录不存在
            content = json.dumps({"error_code": "1009"})
            resp = method.Response_headers(content)
            return resp
        procedure = procedure_base.query.get(procedure_number)
        if procedure is None:
            return jsonify(isModifyProcedure='false')
        procedure.procedure_file = file_path
        procedure.update_time = datetime.datetime.now()
        try:
            db.session.add(procedure)
            db.session.commit()
            return jsonify(isModifyProcedure='true')
        except:
            db.session.rollback()
            if os.path.isfile(file_path):
                os.remove(file_path)
            return jsonify(isModifyProcedure='false')
    elif request.method == 'GET':
        data = method.get_request(request)
        # 检测前台参数是否合法
        if ('procedureNumber' in data):
            procedure_number = data['procedureNumber']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (procedure_number is None) or (procedure_number == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        if 'purpose' in data:
            purpose = data['purpose']
        else:
            purpose = ''
        if 'applicationRange' in data:
            application_range = data['applicationRange']
        else:
            application_range = ''
        if 'terms' in data:
            terms = data['terms']
        else:
            terms = ''
        if 'proof' in data:
            proof = data['proof']
        else:
            proof = ''
        if 'revision' in data:
            revision = data['revision']
        else:
            revision = ''
        procedure = procedure_base.query.get(procedure_number)
        # procedure.procedure_name = procedure_name
        # procedure.chapter = chapter
        procedure.purpose = purpose
        procedure.applicationRange = application_range
        procedure.terms = terms
        procedure.according = proof
        procedure.revision = revision
        procedure.update_time = datetime.datetime.now()
        try:
            db.session.add(procedure)
            db.session.commit()
            return jsonify(isModifyProcedure='true')
        except:
            db.session.rollback()
            return jsonify(isModifyProcedure='false')



# 修改手册的测试html
@input.route('/procedure/modify1', methods=['GET', 'POST'])
def modify_procedure_test():
    if request.method == 'POST':
        file = request.files['manualFile']
        data = request.form.to_dict()
        # 检测前台参数是否合法
        if 'procedureNumber' in data:
            procedure_number = data['procedureNumber']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (procedure_number is None) or (procedure_number == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        # if '--' not in manual_name:
        #     # 文件名不包含--
        #     content = json.dumps({"error_code": "1005"})
        #     resp = method.Response_headers(content)
        #     return resp
        # right, file_path = method.upload_path(manual_name)
        # if not right:
        #     content = json.dumps({"error_code": "1010"})
        #     resp = method.Response_headers(content)
        #     return resp
        procedure_new = procedure_base.query.get(procedure_number)
        file_path = method.upload_path(procedure_new.use_handbook_name+'--'+procedure_new.chapter+
                                       '--'+procedure_new.procedure_name)
        file_extension = os.path.splitext(file.filename)[1]
        file_path = file_path + file_extension
        print(file_path)
        if not os.path.exists(file_path):
            # 文件不存在
            content = json.dumps({"error_code": "1008"})
            resp = method.Response_headers(content)
            return resp
        try:
            file.save(file_path)
        except:
            # 该目录不存在
            content = json.dumps({"error_code": "1009"})
            resp = method.Response_headers(content)
            return resp
        procedure = procedure_base.query.get(procedure_number)
        if procedure is None:
            return jsonify(isAddProcedure='false')
        procedure.procedure_file = file_path
        procedure.update_time = datetime.datetime.now()
        try:
            db.session.add(procedure)
            db.session.commit()
            return jsonify(isAddProcedure='true')
        except:
            db.session.rollback()
            if os.path.isfile(file_path):
                os.remove(file_path)
            return jsonify(isAddProcedure='false')
    return render_template('upload_procedure.html')
#查看程序
@input.route('/procedure/check', methods=['GET', 'POST'])
def check_procedure():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'procedureNumber' in data:
        procedure_number = data['procedureNumber']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (procedure_number is None) or (procedure_number == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    procedure = procedure_base.query.get(procedure_number)
    return jsonify(manualName=method.is_empty(procedure.use_handbook_name),procedureNumber=procedure.procedure_number,
                   procedureName=procedure.procedure_name, purpose=method.is_empty(procedure.purpose),
                   applicationRange=method.is_empty(procedure.applicationRange), terms=method.is_empty(procedure.terms),
                   proof=method.is_empty(procedure.according), revision=method.is_empty(procedure.revision),
                   createTime=date_encoder.default(procedure.creation_time),
                   updateTime=date_encoder.default(procedure.update_time))

#删除程序
@input.route('/procedure/delete', methods=['GET', 'POST'])
def del_procedure():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'procedureNumber' in data:
        procedure_number = data['procedureNumber']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (procedure_number == None) or (procedure_number == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    # dir_name1, dir_name2, file_name = method.file_name_split(name)
    #file_path = method.handbook_path(name)
    try:
        procedure = procedure_base.query.get(procedure_number)
        json_str = {'manualName': method.is_empty(procedure.use_handbook_name),
                    'procedureNumber': procedure.procedure_number,
                    'procedureName': procedure.procedure_name, 'purpose': method.is_empty(procedure.purpose),
                    'applicationRange': method.is_empty(procedure.applicationRange),
                    'terms': method.is_empty(procedure.terms),
                    'proof': method.is_empty(procedure.according), 'revision': method.is_empty(procedure.revision),
                    'createTime': date_encoder.default(procedure.creation_time),
                    'updateTime': date_encoder.default(procedure.update_time), 'isDeleteProcedure':'true'}
        content = json.dumps(json_str)
        print(content)
        db.session.delete(procedure)
        db.session.commit()
        resp = method.Response_headers(content)
        return resp
    except:
        db.session.rollback()
        return jsonify(isDeleteProcedure='false')
