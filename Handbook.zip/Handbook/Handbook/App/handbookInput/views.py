#-*-coding:utf-8-*-
from flask import Blueprint

input = Blueprint('handbookInput',__name__)

#手册录入

#手册录入管理
@input.route('/handbook',methods=['GET'])
def show_handbook():
#显示手册列表
    return

#新建手册
@input.route('/handbook/add',methods=['GET','POST'])
def add_handbook():
    return

#修改手册
@input.route('/handbookInput/handbook/modify',methods=['GET','POST'])
def modify_handbook():
    return

#手册查看
@input.route('/handbookInput/handbook/check',methods=['GET'])
def check_handbook():
    return

#手册删除
@input.route('/handbookInput/handbook/delete',methods=['GET','POST'])
def del_handbook():
    return


#程序录入
@input.route('/handbookInput/procedure',methods=['GET'])
def show_procedure():
#显示工作程序列表
    return
def find_procedure():
#查询程序
    return

#新建程序
@input.route('/handbookInput/procedure/add',methods=['GET','POST'])
def add_procedure():
    return

#修改程序
@input.route('/handbookInput/procedure/modify',methods=['GET','POST'])
def modify_procedure():
    return

#查看程序
@input.route('/handbookInput/procedure/check',methods=['GET'])
def check_procedure():
    return

#删除程序
@input.route('/handbookInput/procedure/delete',methods=['GET','POST'])
def del_procedure():
    return
