#-*-coding:utf-8-*-
from flask import request
from flask import jsonify, render_template
from App.handbookInput import input
import os
import json
from App.Method import method, DateEncoder
import datetime
from App.models import handbook_base, db, user_base

#手册录入

#手册录入管理
@input.route('/handbook')
def show_handbook():
#显示手册列表
    direct = "C:\\Users\\Administrator\\Desktop\\手册整理"
    files = []
    for file in os.listdir(direct):
        file_path = os.path.join(direct, file)
        if os.path.isdir(file_path):
            files.append(file)
    print(files)
    return jsonify(manualName=files)

#新建手册
@input.route('/handbook/add', methods=['GET', 'POST'])
def add_handbook():
    if request.method == 'POST':
        file = request.files['manualFile']
        data = request.form.to_dict()
        # 检测前台参数是否合法
        if 'manualName' in data:
            manual_name = data['manualName']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (manual_name == None) or (manual_name == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        if '--' not in manual_name:
            # 文件名不包含--
            content = json.dumps({"error_code": "1005"})
            resp = method.Response_headers(content)
            return resp
        file_path = method.upload_path(manual_name)
        file_extension = os.path.splitext(file.filename)[1]
        file_path = file_path + file_extension
        if os.path.exists(file_path):
            # 文件已存在
            content = json.dumps({"error_code": "1007"})
            resp = method.Response_headers(content)
            return resp
        try:
            file.save(file_path)
            return jsonify(isAddManual='true')
        except:
            # 该目录存在
            content = json.dumps({"error_code": "1009"})
            resp = method.Response_headers(content)
            return resp
            return jsonify(isAddManual='false')
    elif request.method == 'GET':
        data = method.get_request(request)
        # 检测前台参数是否合法
        if 'manualName' in data:
            manual_name = data['manualName']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (manual_name == None) or (manual_name == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        if '--' not in manual_name:
            # 文件名不包含--
            content = json.dumps({"error_code": "1005"})
            resp = method.Response_headers(content)
            return resp
        file_path = method.upload_path(manual_name)
        dir_name1, dir_name2, file_name = method.file_name_split(manual_name)
        handbook = handbook_base(handbook_name=file_name,
                                 handbook_file=file_path, creation_time=datetime.datetime.now(),
                                 update_time=datetime.datetime.now())
        try:
            db.session.add(handbook)
            db.session.commit()
            return jsonify(isAddManual='true')
        except:
            db.session.rollback()
            return jsonify(isAddManual='false')
    else:
        return render_template('upload.html')


#修改手册
@input.route('/handbook/modify', methods=['GET', 'POST'])
def modify_handbook():
    if request.method == 'POST':
        file = request.files['manualFile']
        data = request.form.to_dict()
        # 检测前台参数是否合法
        if 'manualName' in data:
            manual_name = data['manualName']
        else:
            # 前台参数不合法
            content = json.dumps({"error_code": "1001"})
            resp = method.Response_headers(content)
            return resp
        if (manual_name == None) or (manual_name == ""):
            # 文件名为空
            content = json.dumps({"error_code": "1004"})
            resp = method.Response_headers(content)
            return resp
        if '--' not in manual_name:
            # 文件名不包含--
            content = json.dumps({"error_code": "1005"})
            resp = method.Response_headers(content)
            return resp
        file_path = method.upload_path(manual_name)
        file_extension = os.path.splitext(file.filename)[1]
        file_path = file_path + file_extension
        if not os.path.exists(file_path):
            # 文件不存在
            content = json.dumps({"error_code": "1008"})
            resp = method.Response_headers(content)
            return resp
        try:
            file.save(file_path)
            return jsonify(isModifyManual='true')
        except:
            return jsonify(isModifyManual='false')
    return render_template('upload.html')

#手册查看
@input.route('/handbookInput/handbook/check', methods=['GET', 'POST'])
def check_handbook():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'manualName' in data:
        manual_name = data['manualName']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (manual_name == None) or (manual_name == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    try:
        handbook = handbook_base.query.get(manual_name)
        return jsonify(manualName=handbook.handbook_name,
                       createTime=handbook.creation_time, updateTime=handbook.update_time, exists='true')
    except:
        db.session.rollback()
        return jsonify(exists='false')

#手册删除
@input.route('/handbook/delete', methods=['GET', 'POST'])
def del_handbook():
    data = method.get_request(request)
    # 检测前台参数是否合法
    if 'manualName' in data:
        name = data['manualName']
    else:
        # 前台参数不合法
        content = json.dumps({"error_code": "1001"})
        resp = method.Response_headers(content)
        return resp
    if (name == None) or (name == ""):
        # 参数名为空
        content = json.dumps({"error_code": "1004"})
        resp = method.Response_headers(content)
        return resp
    dir_name1, dir_name2, file_name = method.file_name_split(name)
    file_path = method.upload_path(name)
    try:
        handbook = handbook_base.query.filter_by(handbook_name=file_name, handbook_file=file_path).first()
        createTime = handbook.creation_time
        updateTime = handbook.update_time
        json_str = {'manualName': name, 'createTime': createTime, 'updateTime': updateTime, 'isDeleteManual': 'true'}
        content = json.dumps(json_str, cls=DateEncoder)
        print(content)
        db.session.delete(handbook)
        db.session.commit()
        resp = method.Response_headers(content)
        return resp
    except:
        db.session.rollback()
        return jsonify(isDeleteManual='false')


#程序录入
@input.route('/handbookInput/procedure',methods=['GET'])
def show_procedure():
#显示工作程序列表
    return
def find_procedure():
#查询程序
    return

#新建程序
@input.route('/handbookInput/procedure/add',methods=['GET','POST'])
def add_procedure():
    return

#修改程序
@input.route('/handbookInput/procedure/modify',methods=['GET','POST'])
def modify_procedure():
    return

#查看程序
@input.route('/handbookInput/procedure/check',methods=['GET'])
def check_procedure():
    return

#删除程序
@input.route('/handbookInput/procedure/delete',methods=['GET','POST'])
def del_procedure():
    return
